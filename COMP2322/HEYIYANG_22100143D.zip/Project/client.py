import socket
import datetime

# Server address and port
SERVER_HOST = '127.0.0.1'
SERVER_PORT = 8000

# Create a socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Connect to the server
client_socket.connect((SERVER_HOST, SERVER_PORT))

# Prepare the If-Modified-Since header with today's date at 15:00:00
today = datetime.datetime.now()
three_pm_today = datetime.datetime(today.year, today.month, today.day, 15, 0, 0)
formatted_time = three_pm_today.strftime('%a, %d %b %Y %H:%M:%S GMT')

# Prepare HTTP GET request
# 1.200 OK GET request
# http_request = f'GET /index.html HTTP/1.1\r\nHost: {SERVER_HOST}\r\nUser-Agent: MyClient/1.0\r\nIf-Modified-Since: {formatted_time}\r\nConnection: keep-alive\r\n\r\n'

# 2.304 Not Modified GET request
# Prepare the If-Modified-Since header with today's date at 17:00:00
# today = datetime.datetime.now()
# three_pm_today = datetime.datetime(today.year, today.month, today.day, 17, 0, 0)
# formatted_time = three_pm_today.strftime('%a, %d %b %Y %H:%M:%S GMT')
# http_request = f'GET /index.html HTTP/1.1\r\nHost: {SERVER_HOST}\r\nUser-Agent: MyClient/1.0\r\nIf-Modified-Since: {formatted_time}\r\nConnection: close\r\n\r\n'

# 3.404 Not Found GET request
# http_request = f'GET /index123.html HTTP/1.1\r\nHost: {SERVER_HOST}\r\nUser-Agent: MyClient/1.0\r\nIf-Modified-Since: {formatted_time}\r\nConnection: close\r\n\r\n'

# 4.400 Bad Request GET request
# http_request = 'GET 123'

# Prepare HTTP HEAD request
# 1.200 OK HEAD request
http_request = f'HEAD /index.html HTTP/1.1\r\nHost: {SERVER_HOST}\r\nUser-Agent: MyClient/1.0\r\nIf-Modified-Since: {formatted_time}\r\nConnection: close\r\n\r\n'

# 2.304 Not Modified HEAD request
# Prepare the If-Modified-Since header with today's date at 17:00:00
# today = datetime.datetime.now()
# three_pm_today = datetime.datetime(today.year, today.month, today.day, 17, 0, 0)
# formatted_time = three_pm_today.strftime('%a, %d %b %Y %H:%M:%S GMT')
#http_request = f'HEAD /index.html HTTP/1.1\r\nHost: {SERVER_HOST}\r\nUser-Agent: MyClient/1.0\r\nIf-Modified-Since: {formatted_time}\r\nConnection: close\r\n\r\n'

# 3.404 Not Found HEAD request
#http_request = f'HEAD /index1.html HTTP/1.1\r\nHost: {SERVER_HOST}\r\nUser-Agent: MyClient/1.0\r\nIf-Modified-Since: {formatted_time}\r\nConnection: close\r\n\r\n'

# 4.400 Bad Request HEAD request
#http_request = f'HEAD 123'


# Send the request
client_socket.send(http_request.encode())

# Receive the response
response = client_socket.recv(4096)  # Adjust the buffer size if expecting large data

# Print the response
print(response.decode())

# Close the connection
client_socket.close()