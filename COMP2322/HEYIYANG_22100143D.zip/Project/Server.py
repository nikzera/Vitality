import socket
import os
import datetime
import threading

# Define socket host and port
SERVER_HOST = '127.0.0.1'
SERVER_PORT = 8000
# Open log file for append
log_file = open("log.txt", "w")
log_file.write("HTTP Server Log\n")
log_file.close()

# Create socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((SERVER_HOST, SERVER_PORT))
server_socket.listen(5)
print(f"Listening on port {SERVER_PORT} ...")

def get_content_type(filename):
    if filename.endswith('.html'):
        return 'text/html'
    elif filename.endswith('.jpg') or filename.endswith('.jpeg'):
        return 'image/jpeg'
    elif filename.endswith('.png'):
        return 'image/png'
    elif filename.endswith('.css'):
        return 'text/css'
    elif filename.endswith('.js'):
        return 'application/javascript'
    else:
        return 'application/octet-stream'

def handle_client_connection(client_connection, client_address):
    keep_alive = False  # Set to True to keep the connection alive
    if_modified_since = None  # Set to the value of the If-Modified-Since header
    print(f"New connection from: {client_address}")
    try:
        request = client_connection.recv(1024).decode()
        headers = request.split('\n')
        request_line = headers[0].split()
        method, filename = request_line[0], request_line[1] if len(request_line) > 1 else '/'
        if len(request_line) != 3:
            raise ValueError("Malformed request line")

        # Default filename to index.html if accessing root
        if filename == '/':
            filename = '/index.html'

        # Parse headers for Connection and If-Modified-Since
        for header in headers[1:]:
            if 'Connection:' in header:
                connection_value = header.split(':')[1].strip().lower()
                if connection_value == 'keep-alive':
                    keep_alive = True
                if connection_value == 'close':
                    keep_alive = False
            if 'If-Modified-Since:' in header:
                if_modified_since = header.split(':', 1)[1].strip()

        # File path
        folder = os.path.abspath(os.path.dirname(__file__))
        filepath = folder + filename

        # Check if the file exists
        if not os.path.isfile(filepath):
            response = 'HTTP/1.1 404 Not Found\r\n\r\n'.encode('utf-8')
            response_line = '404 Not Found'
        else:
            # Check if the file was modified
            last_modified = os.path.getmtime(filepath)
            last_modified_dt = datetime.datetime.fromtimestamp(last_modified)
            last_modified_str = last_modified_dt.strftime('%a, %d %b %Y %H:%M:%S GMT')
            if if_modified_since:
                if_modified_since_dt = datetime.datetime.strptime(if_modified_since, '%a, %d %b %Y %H:%M:%S GMT')
                if last_modified_dt <= if_modified_since_dt:
                    response = 'HTTP/1.1 304 Not Modified\r\n\r\n'.encode('utf-8')
                    response_line = '304 Not Modified'
                    client_connection.sendall(response)
                    return 

            content_type = get_content_type(filename)
            headers = f'HTTP/1.1 200 OK\r\nContent-Type: {content_type}\r\nLast-Modified: {last_modified_str}\r\nConnection: {("keep-alive" if keep_alive else "close")}\r\n\r\n'.encode('utf-8')
            response_line = '200 OK'

            if method == 'GET':
                # Read file content only if it's a GET request
                with open(filepath, 'rb') as file:
                    content = file.read()
                response = headers + content
            else:
                # For HEAD request, send only headers
                response = headers

    except Exception as e:
        print(f"Error: {e}")
        response = 'HTTP/1.1 400 Bad Request\n\nMalformed request line\r\n\r\n'.encode('utf-8')
        response_line = '400 Bad Request'

    # Log request
    finally:
        current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        client_ip = client_connection.getpeername()[0]
        log_entry = f"Time: {current_time}, Client IP: {client_ip}, Requested File: {filename}, Response: {response_line}\n"
        with open("log.txt", "a") as log_file:
            log_file.write(log_entry)
        if isinstance(response, str):
            response = response.encode('utf-8')
        client_connection.sendall(response)
        if not keep_alive:
            print(f"Connection closed, the client_address is: {client_address}")
            client_connection.close()
        else:
            print(f"Connection kept alive, the client_address is: {client_address}")

while True:
    # Wait for client connections
    client_connection, client_address = server_socket.accept()
    # Create and start a new thread for each client connection
    client_thread = threading.Thread(target=handle_client_connection, args=(client_connection, client_address))
    client_thread.start()



