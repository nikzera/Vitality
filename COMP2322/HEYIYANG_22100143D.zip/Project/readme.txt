You have to open the entire project folder when you use the vscode or other IDE
You have to click the run server.py file before use web to connect to the localhost:8000 or use other way to connect to the host
You  can type localhost:8000 on the edge to check if the log write html and jpg seperatly
The client.py file are provided for you to check four types of response statuses
When you run client.py, make sure run python file in dedicate terminal

You have to use this formate when you write a python code in the client to check if html file are modified

//

import datetime

today = datetime.datetime.now()
three_pm_today = datetime.datetime(today.year, today.month, today.day, 17, 0, 0) // 17, 0, 0 means today 17pm
formatted_time = three_pm_today.strftime('%a, %d %b %Y %H:%M:%S GMT')
http_request = f'HEAD /index.html HTTP/1.1\r\nHost: {SERVER_HOST}\r\nUser-Agent: MyClient/1.0\r\nIf-Modified-Since: {formatted_time}\r\nConnection: close\r\n\r\n'

\\

PLEASE FOLLOWS THE REPORT STEP WHEN YOU TRY TO CONNECT TO THIS SERVER!!!
